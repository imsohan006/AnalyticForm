angular
    .module('analyticalapp',[])
    .controller('analyticalcontroller',['$scope','$window',function($scope,$window){

        $scope.analytics = function(){
            $scope.configrinse = true;
            $scope.configswab = true;
            $scope.isaddMOC = true;
            $scope.define = 'Yes';
            $scope.methodId = 'AMX11/11CH/001';
            $scope.lod = 8;
            $scope.loq = 12;
            $scope.count = 1;
        }

        $scope.changetarget = function(target){
            
            $scope.configrinse = true;
            $scope.configswab = true;
            $scope.isaddMOC = true;
            $scope.define = 'Yes';
            $scope.recoveryswab = 'Yes';
            $scope.usedmethod = undefined;
            $scope.solventname = undefined;
            $scope.solventquantity = undefined;
            $scope.defaultrecovery = undefined;
            $scope.recovery = undefined;
            $scope.tntc = undefined;
            $scope.tftc = undefined;

            if(target == 'API'){
               
            }else if(target == 'Cleaning Agent'){
                
            }else if(target == 'Bioburden'){
                $scope.methodused = 'Membrane Filtration';
            }else{
                $scope.methodused = 'Get Clot Method';
            }
        }

        $scope.clickswab = function(){
            $scope.configswab = false;
            $scope.tntc = 300;
            $scope.tftc = 25;
        }

        $scope.reversswab = function(){
            $scope.configswab = true;
            $scope.tntc = undefined;
            $scope.tftc = undefined;
        }

        $scope.clickrinse = function(){
            $scope.configrinse = false;
        }

        $scope.reversrinse = function(){
            $scope.configrinse = true;
        }

        $scope.addMOC = function(){
            $scope.isaddMOC = false;
        }

        $scope.changemoc = function(moc){
            if(moc == 'Stainless Steel'){
                $scope.usedmethod = 'HPLC';
                $scope.solventname = 'Ethanol';
                $scope.solventquantity = 100;
                $scope.defaultrecovery = 78;
                $scope.recovery = 82;
                $scope.solventvolume = 81;
            }
        }

        $scope.removeMOC = function(){
            $scope.isaddMOC = true;
            //if(moc == 'Stainless Steel'){
                $scope.usedmethod = undefined;
                $scope.solventname = undefined;
                $scope.solventquantity = undefined;
                $scope.defaultrecovery = undefined;
                $scope.recovery = undefined;
                $scope.solventvolume = undefined;
            //}
        }

        $scope.resetAll = function(){
            if (confirm('Are you sure you want to cancel this?')) {
                $scope.target = undefined;
                $scope.changetarget(null);
            }
        }

        $scope.save = function(){
            $scope.target = undefined;
            $window.alert("Data Updated...");
        }

    }])
    .directive('addDivDirective', function() {
        return {
          restrict: 'A',
          scope: true,
          template: '<a style="margin-left: 40px;" ng-click="addedMOC(count)"><i class="fa fa-plus-square"></i> Add MOC</a> or <a ng-click="addedMOC()">create a new MOC</a>',
          controller: function($scope, $element, $compile) {
            $scope.clicked = 0;
            $scope.click = function(count) {
              //$('body').append($compile($('.form-group').clone())($scope));
                $scope.count = count + 1;
            }
          }
        }
      });
