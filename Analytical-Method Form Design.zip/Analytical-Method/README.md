

# Form Design For Analytical Method

1.  All parts covered but for configuring rinse parameter the is no information about fields covered but       as i seen in prototype i create only that.

2. Added MOC support but only for one value.




